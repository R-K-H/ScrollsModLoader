#!/bin/bash
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
if [ -d /Library/Frameworks/Mono.framework ]; then
	mono $DIR/ScrollsModLoader.exe
else
	osascript -e 'display dialog "Mono is not installed, but required to run the Scrolls Summoner.\n\nVisit http://www.go-mono.com/mono-downloads/download.html to get the latest version." buttons {"OK"} with icon caution' > /dev/null
fi